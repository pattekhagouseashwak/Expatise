module.exports = {
    service: 'gmail',
    username: 'no-reply@auctionjournal.com',
    password:'Skipdreibelbis@1607',

    username_notify:"notifications@auctionjournal.com",
    username_support:"support@auctionjournal.com",
    username_listing:"listings@auctionjournal.com",
    username_newsLetter:"newsletter@auctionjournal.com",
    username_suggestions:"suggestions@auctionjournal.com",
    username_auctionLaws:"auctionlaws@auctionjournal.com",
    username_advertise:"advertisement@auctionjournal.com",
    username_bussiness:"business@auctionjournal.com",

};