const {postTestQuestions, getTestQuestions, removeTestQuestion, searchTestQuestion} = require('./drivingmaterial.service')

module.exports ={postTestQuestions, getTestQuestions,removeTestQuestion, searchTestQuestion}