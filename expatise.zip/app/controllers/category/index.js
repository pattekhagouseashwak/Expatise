const {addCategoryNames, getCategoryNames, removeCategoryNames} = require('./category.service')

module.exports ={addCategoryNames, getCategoryNames,removeCategoryNames}