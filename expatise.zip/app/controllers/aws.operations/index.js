const {uploadFile, removeFile} = require('./aws.service')

module.exports ={uploadFile, removeFile}