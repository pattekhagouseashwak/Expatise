const {getProfile, editProfile, createProfile} = require('./profile.service')

module.exports = {getProfile, editProfile, createProfile}