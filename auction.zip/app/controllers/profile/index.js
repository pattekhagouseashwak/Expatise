const {myProfile} = require('./myProfile')
const {editProfile} = require('./editProfile')

module.exports ={myProfile,editProfile}