const{validateEditProfile} = require('./validateEditProfile')

module.exports = {validateEditProfile};