const { uploadZipcode } = require('./uploadZipcode')
const {findLocation} = require('./findLocation')

module.exports = {uploadZipcode,findLocation}
