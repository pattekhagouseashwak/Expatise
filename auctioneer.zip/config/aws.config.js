module.exports = {
    AWS_ACCESS_KEY_ID : 'AKIAXJ24LME36FLEMRVC',
    AWS_SECRET_ACCESS_KEY : '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',
    AWS_REGION : 'us-east-1',
    AWS_BUCKET_NAME : 'auctionjournalmain',
    AWS_Uploaded_File_URL_LINK :"https://auctionjournalmain.s3.amazonaws.com/"
};