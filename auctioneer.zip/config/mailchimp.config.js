module.exports = mailchimpConfig = {
    apiKey: 'd1d8df8de65c11f289644b53cafb8d4f-us5',
    server: "us5",
};