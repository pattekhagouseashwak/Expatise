const {getPasses} = require('./getPasses')
const {generateMypass} = require('./generateMypass')

module.exports = {getPasses,generateMypass}