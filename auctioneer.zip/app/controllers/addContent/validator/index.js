const { validatePostContent } = require('./validatePostContent')

module.exports = {validatePostContent}
