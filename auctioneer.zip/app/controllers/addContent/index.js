const { postContent } = require('./postContent')

module.exports = {postContent}