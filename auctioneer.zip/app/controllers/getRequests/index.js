const {getRequests} = require('./getRequests')
const {createGetRequest} = require('./createGetRequest')
module.exports = {getRequests,createGetRequest}