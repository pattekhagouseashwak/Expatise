const{validateAuctioneerEditProfile,validateBidderEditProfile} = require('./validateEditProfile')
const{validateuploadPhoto} = require('./validateuploaddPhoto')

module.exports = {validateAuctioneerEditProfile,validateBidderEditProfile,validateuploadPhoto};