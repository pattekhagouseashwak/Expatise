const {subscribeNewsletter} = require('./newsletter')
const {unsubscribeNewsletter} = require('./newsletter')
module.exports = {subscribeNewsletter, unsubscribeNewsletter}