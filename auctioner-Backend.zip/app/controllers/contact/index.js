const { contactUs } = require('./contactUs')
const { gotATip } = require('./gotATip')
const { advertiseWithUs } = require('./advertiseWithUs')

module.exports = {contactUs, gotATip, advertiseWithUs}