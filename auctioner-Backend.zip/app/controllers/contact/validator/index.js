const { validatePostContent } = require('./validatePostContent')
const {validateCreateRecommandVideo} = require('./validateCreateRecommandVideo')

module.exports = {validatePostContent,validateCreateRecommandVideo}
