const { handleError } = require('../../middleware/utils')

const AuctionListing = require('../../models/auctionListing')

/**
 * Register function called by route
 * @param {Object} req - request object
 * @param {Object} res - response object
 */



const calender = async (req, res) => {
  try {
     
    await AuctionListing.aggregate(
      [   
        { $match: { AuctionMonthYear: "2021-06"}  },

        { "$group": {
            
            "_id": "$AuctionDate",
  
            Auctioneer_Data:{
              
                   $push:"$$ROOT"
                 
                 }
 
              }
       }
      ])
              .then((data)=>{
                            res.status(200).send({ status: 200, message: "successfully fetch AuctionLisintg Details for current month",data})
                            }
                                        ).catch(Err => {
                                            res.status(500).send({
                                            status: 500,    
                                            message:
                                                Err.message || "Some error occurred while fetching AuctionLisintg."
                                            });
                                        });
  } catch (error) {
    console.log(error)
    handleError(res, error)
  }
}

module.exports = { calender }