const { validateCreateListing } = require('./validateCreateListing')

module.exports = {validateCreateListing}
