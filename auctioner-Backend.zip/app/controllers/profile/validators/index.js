const{validateAuctioneerEditProfile,validateBidderEditProfile} = require('./validateEditProfile')

module.exports = {validateAuctioneerEditProfile,validateBidderEditProfile};