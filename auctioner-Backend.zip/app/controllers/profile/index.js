const {auctioneerProfile, bidderProfile} = require('./myProfile')
const {editAuctioneerProfile, editBidderProfile} = require('./editProfile')
const {bidHistory} = require('./bidHistory')

module.exports ={bidderProfile, auctioneerProfile,editAuctioneerProfile, editBidderProfile, bidHistory}