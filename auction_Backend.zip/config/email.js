module.exports = {
    service: 'gmail',
    username: 'no-reply@auctionjournal.com',
    password:'Skipdreibelbis@1607'
};